#ifndef _XENO_ASM_BLACKFIN_BIND_H
#define _XENO_ASM_BLACKFIN_BIND_H

#include <asm-generic/xenomai/bind.h>

#endif /* _XENO_ASM_BLACKFIN_BIND_H */
