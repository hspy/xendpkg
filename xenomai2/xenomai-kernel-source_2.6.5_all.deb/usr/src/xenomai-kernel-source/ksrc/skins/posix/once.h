#ifndef _POSIX_ONCE_H
#define _POSIX_ONCE_H

int pse51_once_pkg_init(void);

void pse51_once_pkg_cleanup(void);

#endif /* _POSIX_ONCE_H */
